// import simpleParallax from 'simple-parallax-js';

// Form
import './form/form'


// Hamburger
import './hamburger/hamburger'
import './overlay/overlay'
import './modal/modal'
import './detail/detail'
import './about/about'
import './industries/industries'

// import './header/header'
